var express = require('express');
var exphbs = require('express-handlebars');

var app = express();
var port = 3000;

app.engine('handlebars', exphbs({
	defaultLayout: 'main'
}));
app.set('view engine', 'handlebars');

require('./routes/routes')(app);

app.listen(port);
