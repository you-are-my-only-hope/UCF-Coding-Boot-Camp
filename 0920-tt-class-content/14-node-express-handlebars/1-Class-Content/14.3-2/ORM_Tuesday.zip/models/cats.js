var orm = require('../config/orm.js');

module.exports = {
	all: function() {
		orm.all('cats', function(data) {
			console.log(data);
		})
	}
}