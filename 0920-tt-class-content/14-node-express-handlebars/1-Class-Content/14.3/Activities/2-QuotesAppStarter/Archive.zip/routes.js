var queries = require('./queries');

module.exports = function(app, connection) {
	app.get('/', function(req, res) {
		queries.selectQuotes(connection, function(err, data) {
			console.log(err, data);
			res.render('index', {
				quotes: data
			})
		}, ['author', 'quote'])
	})

	app.post('/delete/:id', function(req, res) {
		var id = req.body.id;

		connection.query('DELETE FROM quotes WHERE `id` = ?', [id] ,function(err, data) {
			res.redirect('/');
		})
	});

	app.post('/', function(req, res) {
		connection.query('INSERT INTO quotes (author, quote) VALUES (?, ?)', [req.body.author, req.body.quote], function(err, results) {
			res.redirect('/');
		})
	});

	app.get('/:id', function(req, res) {
		connection.query('SELECT * FROM quotes WHERE `id` = ?', [req.params.id], function(err, data) {
			
			console.log(data);
			res.render('single_quote', data[0])
		})
	});

	app.post('/:id', function(req, res) {
		var author = req.body.author;
		var quote = req.body.quote;
		var id = req.params.id;
		connection.query('UPDATE quotes SET ?, ? WHERE id = ?', [{author: author}, {quote: quote}, id], function(err) {
			console.log(err);
			res.redirect('/');
		})
	})
}







