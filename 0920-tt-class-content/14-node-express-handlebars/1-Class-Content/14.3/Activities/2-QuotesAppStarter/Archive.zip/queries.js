module.exports = {
	selectQuotes: function(connection, callback, columns) {
		connection.query('SELECT ?? FROM quotes', [columns || '*'], callback)
	}
}